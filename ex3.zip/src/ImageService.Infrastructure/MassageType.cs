﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Infrastructure
{
    /// <summary>
    /// the enum MassageType 
    /// </summary>
    public enum MassageType : int
    {
        Config,
        Log,
        
    }
}
