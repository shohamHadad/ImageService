﻿using ImageService.Logging.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Logging
{
    /// <summary>
    /// Interface for LoggingService
    /// </summary>
    public interface ILoggingService
    {
        event EventHandler<MessageRecievedEventArgs> MessageRecieved;
        /// <summary>
        /// The Function receive a message and invoke to loger
        /// </summary>
        /// <param name= message> The function gets a massage to the loger </param>
        /// <param name= type> The function gets a type message </param>
        /// <return> return void </return>
        void Log(string message, MessageTypeEnum type);           // Logging the Message
    }
}
