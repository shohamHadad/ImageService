﻿using ImageService.Commands;
using ImageService.Controller;
using ImageService.Infrastructure;
using ImageService.Logging.Modal;
using ImageService.Modal;
using ImageService.Server;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ImageService.Client
{
    /// <summary>
    /// The class ClientHandler
    /// </summary>
    class ClientHandler : IClientHandler
    {
        private Mutex mtx;

        /// <summary>
        /// The function HandleClient
        /// </summary>
        ///<param name= tcp_client> the gets a tcp_client </param>
        /// <param name= m_controller> the gets a IImageController </param>
        /// <return> void </return>
        public void HandleClient(Tcp_Client client, IImageController m_controller)
        {
            this.RecievedCommand(client, m_controller);
        }
        /// <summary>
        /// The function RecievedCommand
        /// </summary>
        ///<param name= tcp_client> the gets a tcp_client </param>
        /// <param name= m_controller> the gets a IImageController </param>
        /// <return> void </return>
        public void RecievedCommand(Tcp_Client client, IImageController m_controller)
        {
            this.mtx = new Mutex();
            InformConfig config = new InformConfig();
            new Task(() =>
            {
                try
                {
                    while (client.Tc_client.Connected)
                    {
                        string result;
                        string commandLine = client.reader.ReadString();
                        CommandRecievedEventArgs command = JsonConvert.DeserializeObject
                        <CommandRecievedEventArgs>(commandLine);
                        bool answer;
                        string[] args = { };
                        switch (command.CommandID)
                        {
                            case 1:
                                result = m_controller.ExecuteCommand(command.CommandID, args, out answer);
                                config.type = MassageType.Config;
                                config.message = result.Split(',');
                                answer = false;
                                try
                                {
                                    string massage = JsonConvert.SerializeObject(config);
                                    mtx.WaitOne();
                                    client.writer.Write(massage);
                                    client.writer.Flush();
                                    mtx.ReleaseMutex();
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                    //client.Close();
                                }
                                break;
                            case 2:
                                //for a LogCommand
                                result = m_controller.ExecuteCommand(command.CommandID, args, out answer);
                                if (result == null)
                                {
                                    break;
                                }
                                string[] tmp = result.Split(',');
                                foreach (string p in tmp)
                                {
                                    string[] MassageAndTyp = p.Split('#');
                                    MessageTypeEnum msg = MessageTypeEnum.INFO;
                                    switch (MassageAndTyp[1])
                                    {
                                        case "INFO":
                                            msg = MessageTypeEnum.INFO;
                                            break;
                                        case "WARNING":
                                            msg = MessageTypeEnum.WARNING;
                                            break;
                                        case "FAIL":
                                            msg = MessageTypeEnum.FAIL;
                                            break;
                                    }
                                    MessageRecievedEventArgs log =
                                        new MessageRecievedEventArgs(MassageAndTyp[0], msg);
                                    this.SendMessageToGui(client, log);
                                }
                                answer = false;
                                break;
                            case 3:
                                result = m_controller.ExecuteCommand(command.CommandID, command.Args, out answer);
                                break;
                        }

                        Console.WriteLine("Got command: {0}", commandLine);

                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine("dsds");
                }
            }).Start();
        }

        /// <summary>
        /// The Function SendMessageToGui - the function send mwssage to the gui
        /// </summary>
        /// <param name= tcp_client> the gets a tcp_client </param>
        /// <param name= e> the event that received the gui </param>
        /// <return> void </return>
        public void SendMessageToGui(Tcp_Client client, MessageRecievedEventArgs e)
        {
            InformConfig config = new InformConfig();
            config.type = MassageType.Log;
            string[] ans = { e.Message, e.Status.ToString() };
            config.message = ans;
            try
            {
                string massage = JsonConvert.SerializeObject(config);
                mtx.WaitOne();
                client.writer.Write(massage);
                client.writer.Flush();
                mtx.ReleaseMutex();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}