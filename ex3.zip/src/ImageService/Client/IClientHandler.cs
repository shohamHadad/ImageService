﻿using ImageService.Controller;
using ImageService.Logging.Modal;
using ImageService.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Client
{
    /// <summary>
    /// Interface for ClientHandler
    /// </summary>
    public interface IClientHandler
    {
        /// <summary>
        /// The function HandleClient
        /// </summary>
        ///<param name= tcp_client> the gets a tcp_client </param>
        /// <param name= m_controller> the gets a IImageController </param>
        /// <return> void </return>
        void HandleClient(Tcp_Client client, IImageController m_controller);

        /// <summary>
        /// The Function SendMessageToGui - the function send mwssage to the gui
        /// </summary>
        /// <param name= tcp_client> the gets a tcp_client </param>
        /// <param name= e> the event that received the gui </param>
        /// <return> void </return>
        void SendMessageToGui(Tcp_Client tcp_client, MessageRecievedEventArgs e);
    }
}