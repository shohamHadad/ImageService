﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Client
{
    /// <summary>
    /// The class Tcp_Client
    /// </summary>
    public class Tcp_Client
    {
        private NetworkStream Stream;
        private BinaryReader Reader;
        private BinaryWriter Writer;
        private TcpClient m_tcpClient;

        /// <summary>
        /// constuctor
        /// </summary>
        /// <param name= tcp_client>The function gets Tcp client</param>
        public Tcp_Client(TcpClient tcp_client)
        {
            this.m_tcpClient = tcp_client;
            this.Stream = this.m_tcpClient.GetStream();
            this.Reader = new BinaryReader(Stream);
            this.Writer = new BinaryWriter(Stream);
        }

        /// <summary>
        /// The Function get and set NetworkStream stream
        public NetworkStream stream
        {
            get { return Stream; }
            set
            {
                this.Stream = value;
            }
        }

        /// <summary>
        /// The Function get and set BinaryReader reader
        public BinaryReader reader
        {
            get { return this.Reader; }
            set
            {
                this.Reader = value;
            }

        }

        public BinaryWriter writer
        {
            get { return this.Writer; }
            set
            {
                this.Writer = value;
            }

        }

        public TcpClient Tc_client
        {
            get { return this.m_tcpClient; }
            set
            {
                this.m_tcpClient = value;
            }

        }
    }
}