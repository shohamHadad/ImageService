﻿using ImageService.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Commands
{
    /// <summary>
    /// the class CloseCommand
    /// </summary>
    class CloseCommand : ICommand
    {
        private Config config;
        private ImageServer server;

        /// <summary>
        /// constuctor
        /// </summary>
        /// <param name= serv>The function gets ImageServer</param>
        public CloseCommand(ImageServer serv)
        {
            this.server = serv;
            this.config = Config.Instance(null,null);
        }

        /// <summary>
        /// The Function will Execute the command
        /// </summary>
        /// <param name= args> the args to the command </param>
        /// <param name= result> gets false if command executed failed an ture if command executed successfuly </param>
        /// <return> return the result of the command or error message if is failed </return>
        public string Execute(string[] args, out bool result)
        {
            this.server.sendCommand(args[0]);
            result = true;
            return "closed " + args[0]; 
        }
    }
}
