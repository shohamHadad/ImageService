﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Commands
{
    /// <summary>
    /// The class GetConfigCommand
    /// </summary>
    class GetConfigCommand : ICommand
    {


        /// <summary>
        /// The Function will Execute the command
        /// </summary>
        /// <param name= args> the args to the command </param>
        /// <param name= result> gets false if command executed failed an ture if command executed successfuly </param>
        /// <return> return the result of the command or error message if is failed </return>
        public string Execute(string[] args, out bool result)
        {
            string[] tmp = new string[1];
            Config config = Config.Instance(tmp, tmp);
            string s = string.Join(",", config.info);
            string handlers = string.Join(",", config.handlers.ToArray());
            result = true;
            return s + handlers;
        }
    }
}
