﻿using ImageService.Infrastructure.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Commands
{

    /// <summary>
    /// Interface for commands
    /// </summary>
    public interface ICommand
    {
        /// <summary>
        /// The Function will Execute the command
        /// </summary>
        /// <param name= args> the args to the command </param>
        /// <param name= result> gets false if command executed  failed an ture if command executed successfuly </param>
        /// <return> return the result of the command or error message if is failed </return>
        string Execute(string[] args, out bool result);          // The Function That will Execute The 
    }
}