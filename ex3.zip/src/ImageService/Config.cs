﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;


namespace ImageService
{
    class Config
    {
        public string[] info { get; set; }
        public List<string> handlers { get; set; }
        private static Config instance;

        private Config()
        {
            info = new string[5];
            handlers = new List<string>();
        }

        public static Config Instance(string[] inf,string[] handles)
        {
            {
                if (instance == null)
                {
                    instance = new Config();
                    instance.info = inf;
                    //convert from array to List
                    instance.handlers = handles.OfType<string>().ToList();
                }
                return instance;
            }
        }
    }
}
