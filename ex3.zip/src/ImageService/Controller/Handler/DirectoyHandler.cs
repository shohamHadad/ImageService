﻿using ImageService.Modal;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ImageService.Infrastructure;
using ImageService.Infrastructure.Enums;
using ImageService.Logging;
using ImageService.Logging.Modal;
using System.Text.RegularExpressions;

namespace ImageService.Controller.Handlers
{

    /// <summary>
    /// The class DirectoyHandler that handler to the directoy 
    /// </summary>
    public class DirectoyHandler : IDirectoryHandler
    {
        #region Members
        private IImageController m_controller;              // The Image Processing Controller
        private ILoggingService m_logging;
        private FileSystemWatcher m_dirWatcher;             // The Watcher 
        private string m_path;                              // The Path of directory
        #endregion

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name= controller> the function gets a ImageController controller </param>
        /// <param name= log> the function gets a LoggingService log </param>
        public DirectoyHandler(IImageController controller, ILoggingService log)
        {
            this.m_logging = log;
            this.m_controller = controller;

        }
        // The Event That Notifies that the Directory is being closed
        public event EventHandler<DirectoryCloseEventArgs> DirectoryClose;

        /// <summary>
        /// The Function starts Handlering to the directory
        /// The Function Recieves the directory to Handle
        /// </summary>
        /// <param name= dirPath> The function gets the path of the  directory</param>
        /// <return> void </return>
        public void StartHandleDirectory(string dirPath)
        {
            this.m_path = dirPath;
            //creat a FileSystemWatcher and set all his data 
            this.m_dirWatcher = new FileSystemWatcher(this.m_path);

            // Add event handlers.
            this.m_dirWatcher.Created += new FileSystemEventHandler(OnCreat);
            this.m_dirWatcher.Filter = "*";
            //  Begin watching.
            this.m_dirWatcher.EnableRaisingEvents = true;
        }



        /// <summary>
        /// the function runs when command is received.
        /// </summary>
        /// <param name= sender> the function gets sender object </param>
        /// <param name= e> the event that received the command </param>
        /// <return> void </return>
        public void OnCommandRecieved(object sender, CommandRecievedEventArgs e)
        {
            //if its a close command, check if it refers to me
            if (e.CommandID == -1)
            {
                    if (this.m_path.CompareTo(e.RequestDirPath) == 0)
                   {
                        DirectoryCloseEventArgs d = new DirectoryCloseEventArgs(e.RequestDirPath, "close handler to "+e.RequestDirPath);
                        this.CloseHandler(this, d);
                        return;
                    }
            }
            // The Event that will be activated upon new Command
            bool result = false;
            // check if the path is the same as this handler
                if (e.RequestDirPath.CompareTo(this.m_path) == 0)
                {
                    //if e.Arg == m_path
                    string res = this.m_controller.ExecuteCommand(e.CommandID, e.Args, out result);
                    // if command failed
                    if (result == false)
                    {
                        this.m_logging.Log(res, MessageTypeEnum.FAIL);
                    }
                    //if got a warning
                    else if (res.CompareTo("warning") == 0)
                    {
                        this.m_logging.Log(res, MessageTypeEnum.WARNING);
                    }
                    //if succeded
                    else
                    {
                        this.m_logging.Log("added " + res, MessageTypeEnum.INFO);
                    }
                }
        }


        /// <summary>
        /// the function  handlering to certain image types
        /// </summary>
        /// <param name= sender> the function gets sender object </param>
        /// <param name= e> the event that received the command </param>
        /// <return> void </return>
        public void OnCreat(object sender, FileSystemEventArgs e)
        {
            string s = e.FullPath;
            if (s.EndsWith(".png") || s.EndsWith(".jpg") || s.EndsWith(".gif") || s.EndsWith(".bmp"))
            {
                string[] args = { e.FullPath };
                CommandRecievedEventArgs command = new CommandRecievedEventArgs(
                                                    (int)CommandEnum.NewFileCommand, args, m_path);
                this.OnCommandRecieved(this, command);
            }
        }

        /// <summary>
        /// the function stop the handler to the directory.
        /// </summary>
        /// <param name= sender> the function gets sender object </param>
        /// <param name= e> the event that received the command </param>
        /// <return> void </return>
        public void CloseHandler(object sender, DirectoryCloseEventArgs e)
        {
            this.m_dirWatcher.Dispose();
            DirectoryClose?.Invoke(this,e);
            this.m_logging.Log(e.Message, MessageTypeEnum.INFO);
        }

    }
}