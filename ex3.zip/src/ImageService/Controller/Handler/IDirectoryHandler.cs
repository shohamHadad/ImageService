﻿using ImageService.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Controller.Handlers
{


    /// <summary>
    /// Interface of the  DirectoryHandler
    /// </summary>
    public interface IDirectoryHandler
    {
        event EventHandler<DirectoryCloseEventArgs> DirectoryClose;              // The Event That Notifies that the Directory is being closed


        /// <summary>
        /// The Function starts Handlering to the directory
        /// </summary>
        /// <param name= dirPath> The function gets the path of the  directory</param>
        /// <return> void </return>
        void StartHandleDirectory(string dirPath);             // The Function Recieves the directory to Handle

        /// <summary>
        /// the function runs when command is received.
        /// </summary>
        /// <param name= sender> the function gets sender object </param>
        /// <param name= e> the event that received the command </param>
        /// <return> void </return>
        void OnCommandRecieved(object sender, CommandRecievedEventArgs e);     // The Event that will be activated upon new Command

        /// <summary>
        /// the function stop the handler to the directory.
        /// </summary>
        /// <param name= sender> the function gets sender object </param>
        /// <param name= e> the event that received the command </param>
        /// <return> void </return>
        void CloseHandler(object sender, DirectoryCloseEventArgs e);
    }
}