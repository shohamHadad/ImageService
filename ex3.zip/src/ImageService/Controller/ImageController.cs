﻿using ImageService.Commands;
using ImageService.Infrastructure;
using ImageService.Infrastructure.Enums;
using ImageService.Modal;
using ImageService.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Controller
{

    /// <summary>
    /// the class of the ImageController.
    /// </summary>
    public class ImageController : IImageController
    {
        private IImageServiceModal m_modal;                      // The Modal Object
        private Dictionary<int, ICommand> commands;
        public ImageServer server { get; set; }


        /// <summary>
        /// constructor
        /// </summary>
        /// <param name= modal> the function gets the modal  that we created </param>
        public ImageController(IImageServiceModal modal,ImageServer serv)
        {
            m_modal = modal;                    // Storing the Modal Of The System
            this.server = serv;
            commands = new Dictionary<int, ICommand>()
            {
                // For Now will contain NEW_FILE_COMMAND
                { (int) CommandEnum.NewFileCommand, new NewFileCommand (m_modal)},
                { (int) CommandEnum.GetConfigCommand, new GetConfigCommand ()},
                {(int) CommandEnum.CloseCommand, new CloseCommand (this.server) },
                { (int) CommandEnum.LogCommand, new LogCommand () }
            };
        }

        /// <summary>
        /// the function gets a command id an execute it
        /// </summary>
        /// <param name= commandID> the function gets a id of the command </param>
        /// <param name= args> the function gets a args to the command </param>
        /// <param name= result> the function gets false if command executed  failed an ture if command executed successfuly </param>
        /// <return> return the result of the command or error message if is failed </return>
        public string ExecuteCommand(int commandID, string[] args, out bool resultSuccesful)
        {
            return commands[commandID].Execute(args, out resultSuccesful);

        }
    }
}