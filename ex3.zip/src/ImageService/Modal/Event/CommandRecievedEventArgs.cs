﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Modal
{

    /// <summary>
    /// the class  CommandRecievedEventArgs 
    /// </summary>
    public class CommandRecievedEventArgs : EventArgs
    {

        /// <summary>
        ///The funvtion get and set to the command id
        /// </summary>
        /// <return> the function  return the command id </return>
        public int CommandID { get; set; }      // The Command ID

        /// <summary>
        ///The funvtion get and set to the args
        /// </summary>
        /// <return>the function return the args </return>
        public string[] Args { get; set; }

        /// <summary>
        ///The funvtion get and set to the requestDirPath
        /// </summary>
        /// <return> the function return the path to the requested directory </return>
        public string RequestDirPath { get; set; }  // The Request Directory



        /// <summary>
        /// constructor
        /// </summary>
        /// <param name= id>the function gets the id of the event </param>
        /// <param name= args> the function get the args that we receive </param>
        /// <param name= path> the function gets the path to the directory </param>
        public CommandRecievedEventArgs(int id, string[] args, string path)
        {
            CommandID = id;
            Args = args;
            RequestDirPath = path;
        }
    }
}