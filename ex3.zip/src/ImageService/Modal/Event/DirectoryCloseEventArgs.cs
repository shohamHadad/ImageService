﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Modal
{

    /// <summary>
    /// The class DirectoryCloseEventArgs
    /// </summary>
    public class DirectoryCloseEventArgs : EventArgs
    {

        /// <summary>
        ///The funvtion get and set to the directory path.
        /// </summary>
        /// <return>The funvtion return the path to the directory </return>
        public string DirectoryPath { get; set; }


        /// <summary>
        ///The funvtion get and set to the massage
        /// </summary>
        /// <return>The funvtion return the massage </return>
        public string Message { get; set; }             // The Message That goes to the logger


        /// <summary>
        /// constructor
        /// </summary>
        /// <param name= dirPath>The function gets the path to the directory that we want to close </param>
        /// <param name= message>The function gets the message that we write to the logger </param>
        public DirectoryCloseEventArgs(string dirPath, string message)
        {
            DirectoryPath = dirPath;                    // Setting the Directory Name
            Message = message;                          // Storing the String
        }

    }
}