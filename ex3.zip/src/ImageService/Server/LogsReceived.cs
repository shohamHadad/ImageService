﻿using ImageService.Logging.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Server
{
    /// <summary>
    /// the class LogsReceived
    /// </summary>
    class LogsReceived
    {
        public  List<MessageRecievedEventArgs> Event_logs { get; set; }
        private static LogsReceived instance;

        /// <summary>
        /// constuctor
        /// </summary>
        private LogsReceived()
        {
            Event_logs = new List<MessageRecievedEventArgs>();
        }

        /// <summary>
        /// static LogsReceived Instance
        /// </summary>
        public static LogsReceived Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new LogsReceived();
                }
                return instance;
            }
        }

        /// <summary>
        /// The function  add event to log
        /// </summary>
        /// <param name= sender> the function gets sender object </param>
        /// <param name= e> the event that received the command </param>
        /// <return> void </return>
        public void AddEvent(object sender, MessageRecievedEventArgs e)
        {
            if (!this.Event_logs.Contains(e))
            {
                this.Event_logs.Add(e);
            }
        }

    }
}
