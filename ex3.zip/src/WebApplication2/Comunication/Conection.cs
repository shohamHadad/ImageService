﻿using System;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.IO;
using Newtonsoft.Json.Linq;
using ImageService.Modal;
using Newtonsoft.Json;
using ImageService.Infrastructure;
using System.Threading.Tasks;

namespace WebApplication2.Comunication
{


    /// <summary>
    /// Conection
    /// </summary>
    public class Conection
    {
        private Mutex mtx;
        private NetworkStream stream;
        private BinaryWriter writer;
        private BinaryReader reader;
        private static Conection instance;
        public TcpClient Client { get; }

        /// <summary>
        /// Occurs when [receive massege].
        /// </summary>
        public event EventHandler<InformConfig> ReceiveMassege;

        /// <summary>
        /// Prevents a default instance of the <see cref="Conection"/> class from being created.
        /// </summary>
        private Conection()
        {
            IPEndPoint ep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8008);
            this.Client = new TcpClient();
            this.mtx = new Mutex();
            try
            {
                Client.Connect(ep);
                this.stream = Client.GetStream();
                this.writer = new BinaryWriter(this.stream);
                this.reader = new BinaryReader(stream);
            }

            catch (Exception ex)
            {
                Console.WriteLine("Conection " + ex.Message);
            }
            this.Recieve();

        }

        /// <summary>
        /// Gets the instance.
        /// </summary>
        /// <value>
        /// The instance.
        /// </value>
        public static Conection Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Conection();
                }
                return instance;
            }
        }

        /// <summary>
        /// Sends the json.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="CommandRecievedEventArgs"/> instance containing the event data.</param>
        public void SendJson(object sender, CommandRecievedEventArgs e)
        {
            if (Client.Connected)
            {
                try
                {
                    mtx.WaitOne();
                    writer.Write(JsonConvert.SerializeObject(e));
                    writer.Flush();
                    mtx.ReleaseMutex();

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);

                }
            }
        }

        /// <summary>
        /// Recieves this instance.
        /// </summary>
        public void Recieve()
        {
            Task task = new Task(() =>
            {
                InformConfig info;
                try
                {
                    while (Client.Connected)
                    {
                        string answer = reader.ReadString();
                        info = JsonConvert.DeserializeObject<InformConfig>(answer);
                        ReceiveMassege?.Invoke(this, info);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            });
            task.Start();
        }

    }
}