﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{

    /// <summary>
    /// FirstController
    /// </summary>
    /// <seealso cref="System.Web.Mvc.Controller" />
    public class FirstController : Controller
    {
        static HomePage home = new HomePage();
        static ConfigInfo m_config = new ConfigInfo();
        static PhotosModel photos = new PhotosModel(m_config);
        static LogList m_logs = new LogList();

        /// <summary>
        /// Homes the page.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult HomePage()
        {
            return View(home.students);
        }

        // GET: First of Config Info
        /// <summary>
        /// Indexes this instance.
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            //m_config.Handlers
            return View(m_config.Handlers);
        }

        // GET: First of Photos
        /// <summary>
        /// Creates this instance.
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            photos = new PhotosModel(m_config);
            return View(photos.ListOfThumbPath);
        }

        /// <summary>
        /// Gets the log.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JObject GetLog()
        {
            JObject data = new JObject();
            data["m_message"] = "ERROR";
            data["m_type"] = "INFO";
            return data;
        }
        // GET: First of Logs
        /// <summary>
        /// Detailses this instance.
        /// </summary>
        /// <returns></returns>
        public ActionResult Details()
        {
            return View(m_logs.Log_List);
        }
        // GET: Edit
        /// <summary>
        /// Edits the specified handler to remove.
        /// </summary>
        /// <param name="handlerToRemove">The handler to remove.</param>
        /// <returns></returns>
        public ActionResult Edit(string handlerToRemove)
        {
            Handler handler = new Handler(handlerToRemove);
            return View(handler);

        }

        /// <summary>
        /// Images this instance.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Image()
        {
            return View();
        }

        /// <summary>
        /// Deletes the handler request.
        /// </summary>
        /// <param name="handlerToRemove">The handler to remove.</param>
        /// <returns></returns>
        public ActionResult DeleteHandlerRequest(string handlerToRemove)
        {
            m_config.DeleteHandler(handlerToRemove);
            return RedirectToAction("Index");
        }
        /// <summary>
        /// Gets the name of the log.
        /// </summary>
        /// <returns></returns>
        public string getLogName()
        {
            return m_config.LogName;
        }
        /// <summary>
        /// Gets the name of the service.
        /// </summary>
        /// <returns></returns>
        public string getServiceName()
        {
            return m_config.ServiceName;
        }
        /// <summary>
        /// Gets the output dir.
        /// </summary>
        /// <returns></returns>
        public string getOutputDir()
        {
            return m_config.OutputDir;
        }
        /// <summary>
        /// Gets the size of the thumb.
        /// </summary>
        /// <returns></returns>
        public string getThumbSize()
        {
            return m_config.ThumbnailSize;
        }
        /// <summary>
        /// Determines whether [is on start].
        /// </summary>
        /// <returns></returns>
        public string IsOnStart()
        {
            if (m_config.Conected())
            {
                return "Service is conected";
            }
            else
                return "Service is disconected";
        }
        /// <summary>
        /// Views the image.
        /// </summary>
        /// <param name="FullPath">The full path.</param>
        /// <param name="RelativePath">The relative path.</param>
        /// <param name="ThumbnailFullPath">The thumbnail full path.</param>
        /// <param name="ThumbnailRelativePath">The thumbnail relative path.</param>
        /// <returns></returns>
        public ActionResult ViewImage(string FullPath, string RelativePath, string ThumbnailFullPath, string ThumbnailRelativePath)
        {
            Image m = new Image( FullPath, RelativePath, ThumbnailFullPath, ThumbnailRelativePath); 
            return View(m);
        }

        /// <summary>
        /// Pics the number.
        /// </summary>
        /// <returns></returns>
        public string picNum() {
            return photos.ImageNum();
        }

        /// <summary>
        /// Deletes the photo.
        /// </summary>
        /// <param name="FullPath">The full path.</param>
        /// <param name="RelativePath">The relative path.</param>
        /// <param name="ThumbnailFullPath">The thumbnail full path.</param>
        /// <param name="ThumbnailRelativePath">The thumbnail relative path.</param>
        /// <returns></returns>
        public ActionResult DeletePhoto(string FullPath, string RelativePath, string ThumbnailFullPath, string ThumbnailRelativePath)
        {
            Image photo = new Image(FullPath, RelativePath, ThumbnailFullPath, ThumbnailRelativePath);
            return View(photo);
        }
        /// <summary>
        /// Backs to photos.
        /// </summary>
        /// <returns></returns>
        public ActionResult BackToPhotos()
        {
            return RedirectToAction("Create");
        }

        /// <summary>
        /// Deletes the photo from dir.
        /// </summary>
        /// <param name="outputdirPath">The outputdir path.</param>
        /// <param name="thumbnailPath">The thumbnail path.</param>
        /// <returns></returns>
        public ActionResult DeletePhotoFromDir(string outputdirPath, string thumbnailPath)
        {

            System.IO.File.Delete(outputdirPath);
            System.IO.File.Delete(thumbnailPath);
            
            return RedirectToAction("Create");
        }

        /// <summary>
        /// Deletes the photo from list.
        /// </summary>
        /// <returns></returns>
        public ActionResult DeletePhotoFromList()
        {

            return RedirectToAction("Create");
        }

    }
}
