﻿using ImageService.Modal;
using WebApplication2.Comunication;
using Newtonsoft.Json.Linq;
using System;
using ImageService;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ImageService.Infrastructure;
using System.ComponentModel.DataAnnotations;
using ImageService.Infrastructure.Enums;

namespace WebApplication2.Models
{
    /// <summary>
    /// ConfigInfo
    /// </summary>
    public class ConfigInfo
    {
        private Conection connect_channel;

        /// <summary>
        /// Gets or sets the output dir.
        /// </summary>
        /// <value>
        /// The output dir.
        /// </value>
        [Required]
        [Display(Name = "OutputDir")]
        public string OutputDir { get; set; }

        /// <summary>
        /// Gets or sets the name of the service.
        /// </summary>
        /// <value>
        /// The name of the service.
        /// </value>
        [Required]
        [Display(Name = "ServiceName")]
        public string ServiceName { get; set; }

        /// <summary>
        /// Gets or sets the name of the log.
        /// </summary>
        /// <value>
        /// The name of the log.
        /// </value>
        [Required]
        [Display(Name = "LogName")]
        public string LogName { get; set; }

        /// <summary>
        /// Gets or sets the size of the thumbnail.
        /// </summary>
        /// <value>
        /// The size of the thumbnail.
        /// </value>
        [Required]
        [Display(Name = "ThumbnailSize")]
        public string ThumbnailSize { get; set; }

        /// <summary>
        /// Gets or sets the handlers.
        /// </summary>
        /// <value>
        /// The handlers.
        /// </value>
        [Required]
        public List<Handler> Handlers { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConfigInfo"/> class.
        /// </summary>
        public ConfigInfo()
        {
            this.connect_channel = Conection.Instance;
            CommandRecievedEventArgs command = new CommandRecievedEventArgs(1, null, null);
            this.connect_channel.SendJson(this, command);
            this.connect_channel.ReceiveMassege += SetConfig;
        }
        /// <summary>
        /// Conecteds this instance.
        /// </summary>
        /// <returns></returns>
        public bool Conected()
        {
            return this.connect_channel.Client.Connected;
        }

        /// <summary>
        /// Deletes the handler.
        /// </summary>
        /// <param name="handler">The handler.</param>
        public void DeleteHandler(string handler)
        {
            string[] select = new string[1];
            select[0] = handler;
            this.connect_channel.SendJson(this, new CommandRecievedEventArgs((int)CommandEnum.CloseCommand, select, null));
            foreach (Handler h in this.Handlers)
            {
                if (h.handler.Equals(handler))
                {
                    this.Handlers.Remove(h);
                    break;
                }
            }
        }

        /// <summary>
        /// Sets the configuration.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The e.</param>
        private void SetConfig(object sender, InformConfig e)
        {
            if (e.type == MassageType.Config)
            {
                int n = e.message.Length;
                LogName = e.message[2];
                OutputDir = e.message[0];
                ServiceName = e.message[1];
                ThumbnailSize = e.message[3];
                List<Handler> handlers = new List<Handler>();
                for (int i = 4; i < n; i++)
                {
                    handlers.Add(new Handler(e.message[i]));

                }
                this.Handlers = handlers;
            }
        }

    }
}