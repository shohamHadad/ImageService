﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    /// <summary>
    /// Handler
    /// </summary>
    public class Handler
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Handler"/> class.
        /// </summary>
        /// <param name="h">The h.</param>
        public Handler(string h)
        {
            this.handler = h;
        }

        /// <summary>
        /// Gets or sets the handler.
        /// </summary>
        /// <value>
        /// The handler.
        /// </value>
        [Required]
        //DataType(DataType.Text)]
        public string handler { get; set; }


    }
}