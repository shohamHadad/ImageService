﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    /// <summary>
    /// Image
    /// </summary>
    public class Image
    {

        private string path;
        private string thumbPath;
        private string fullPath;
        private string fullThumbPath;
        private int size;
        private int id;

        /// <summary>
        /// Gets or sets the name of the image.
        /// </summary>
        /// <value>
        /// The name of the image.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Image Name")]
        public string ImageName { get; set; }

        /// <summary>
        /// Gets or sets the image year.
        /// </summary>
        /// <value>
        /// The image year.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Image Year")]
        public string ImageYear { get; set; }

        /// <summary>
        /// Gets or sets the image month.
        /// </summary>
        /// <value>
        /// The image month.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Image Month")]
        public string ImageMonth { get; set; }

        /// <summary>
        /// Gets or sets the full path.
        /// </summary>
        /// <value>
        /// The full path.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Path")]
        public string FullPath { get; set; }

        /// <summary>
        /// Gets or sets the relative path.
        /// </summary>
        /// <value>
        /// The relative path.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Path")]
        public string RelativePath { get; set; }

        /// <summary>
        /// Gets or sets the thumbnail full path.
        /// </summary>
        /// <value>
        /// The thumbnail full path.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Path")]
        public string ThumbnailFullPath { get; set; }

        /// <summary>
        /// Gets or sets the thumbnail relative path.
        /// </summary>
        /// <value>
        /// The thumbnail relative path.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Path")]
        public string ThumbnailRelativePath { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Image"/> class.
        /// </summary>
        /// <param name="FullPath">The full path.</param>
        /// <param name="RelativePath">The relative path.</param>
        /// <param name="ThumbnailFullPath">The thumbnail full path.</param>
        /// <param name="ThumbnailRelativePath">The thumbnail relative path.</param>
        public Image(string FullPath, string RelativePath, string ThumbnailFullPath, string ThumbnailRelativePath)
        {
            this.FullPath = FullPath;
            this.RelativePath = RelativePath;
            this.ThumbnailFullPath = ThumbnailFullPath;
            this.ThumbnailRelativePath = ThumbnailRelativePath;
            this.ImageName = Path.GetFileName(ThumbnailRelativePath);
            DateTime dateTime = DateTime.Now;
            TimeSpan offset = dateTime - dateTime.ToUniversalTime();
            try
            {
                dateTime = File.GetLastWriteTimeUtc(FullPath) + offset;
            }
            catch (Exception e)
            {
                dateTime = File.GetCreationTime(path);
            }
            this.ImageYear = dateTime.Year.ToString();
            this.ImageMonth = dateTime.Month.ToString();
        }
    }
}