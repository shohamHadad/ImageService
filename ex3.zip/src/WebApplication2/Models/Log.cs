﻿using ImageService.Logging.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    /// <summary>
    /// Log
    /// </summary>
    public class Log
    {
        /// <summary>
        /// Gets or sets the m message.
        /// </summary>
        /// <value>
        /// The m message.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "m_message")]
        public string m_message { get; set; }

        /// <summary>
        /// Gets or sets the type of the m.
        /// </summary>
        /// <value>
        /// The type of the m.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "m_type")]
        public string m_type { get; set; }


    }
}