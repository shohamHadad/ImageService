﻿using ImageService.Infrastructure;
using ImageService.Infrastructure.Enums;
using ImageService.Logging.Modal;
using ImageService.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication2.Comunication;

namespace WebApplication2.Models
{
    /// <summary>
    /// LogList
    /// </summary>
    public class LogList
    {
        private Conection connect_channel;
        /// <summary>
        /// Gets or sets the log list.
        /// </summary>
        /// <value>
        /// The log list.
        /// </value>
        public List<Log> Log_List { get; set; }

        /// <summary>
        /// Gets or sets the filter.
        /// </summary>
        /// <value>
        /// The filter.
        /// </value>
        public string filter { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="LogList"/> class.
        /// </summary>
        public LogList()
        {
            this.filter = "";
            this.Log_List = new List<Log>();
            this.connect_channel = Conection.Instance;
            this.connect_channel.ReceiveMassege += AddLog;
            CommandRecievedEventArgs com = new CommandRecievedEventArgs((int)CommandEnum.LogCommand, null, null);
            this.connect_channel.SendJson(this, com);
        }

        /// <summary>
        /// Requesteds the list.
        /// </summary>
        /// <returns></returns>
        public List<Log> requestedList()
        {
            List<Log> tmp = new List<Log>();
            if (filter.CompareTo("") == 0)
            {
                return this.Log_List;
            }
            foreach (Log log in this.Log_List)
            {
                if (log.m_type.CompareTo(filter) == 0)
                {
                    tmp.Add(log);
                }
            }
            return tmp;
        }

        /// <summary>
        /// Adds the log.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="information">The information.</param>
        private void AddLog(object sender, InformConfig information)
        {
            if (information.type == MassageType.Log)
            {
                string type = information.message[1];
                switch (type)
                {
                    case "INFO":
                        this.Log_List.Add(new Log()
                        {
                            m_message = information.message[0],
                            m_type = MessageTypeEnum.INFO.ToString()
                        });
                        break;
                    case "WARNING":
                        this.Log_List.Add(new Log()
                        {
                            m_message = information.message[0],
                            m_type = MessageTypeEnum.WARNING.ToString()
                        });
                        break;
                    case "FAIL":
                        this.Log_List.Add(new Log()
                        {
                            m_message = information.message[0],
                            m_type = MessageTypeEnum.FAIL.ToString()
                        });
                        break;
                }
            }
        }
    }
}