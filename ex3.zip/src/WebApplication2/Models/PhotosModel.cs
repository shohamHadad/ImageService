﻿using ImageService.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using WebApplication2.Comunication;

namespace WebApplication2.Models
{
    /// <summary>
    /// PhotosModel
    /// </summary>
    public class PhotosModel
    {
        /// <summary>
        /// Gets or sets the list of thumb path.
        /// </summary>
        /// <value>
        /// The list of thumb path.
        /// </value>
        [Display(Name = "Image")]
        public List<Image> ListOfThumbPath { get; set; }
        /// <summary>
        /// Images the number.
        /// </summary>
        /// <returns></returns>
        public string ImageNum() {
            return ListOfThumbPath.Count.ToString();

        }
        public Conection client;
        private ConfigInfo config;

        /// <summary>
        /// Initializes a new instance of the <see cref="PhotosModel"/> class.
        /// </summary>
        /// <param name="t_config">The t configuration.</param>
        public PhotosModel(ConfigInfo t_config)
        {
            ListOfThumbPath = new List<Image>();
            this.config = t_config;
            this.client = Conection.Instance;
            this.client.ReceiveMassege += AddImage;
            while (config.OutputDir == null)
            {
            }
            string outputDir = config.OutputDir;
            if (outputDir != "")
            {
                if (Directory.Exists(outputDir)) {
                    string[] directoryOrigin = Directory.GetFiles(outputDir, "*", SearchOption.AllDirectories);
                    if (Directory.Exists(outputDir + "\\Thumbnails"))
                    {
                        string[] directoryThumb = Directory.GetFiles(outputDir + "\\Thumbnails", "*", SearchOption.AllDirectories);
                        foreach (string image in directoryOrigin)
                        {

                            if (!image.Contains("Thumbnails"))
                            {
                                var tokens = Regex.Split(image, "OutputDir");
                                string originPathPhoto = "..\\..\\OutputDir" + tokens[1];

                                foreach (string thumbPhoto in directoryThumb)
                                {
                                    if (Path.GetFileName(thumbPhoto) == Path.GetFileName(image))
                                    {
                                        var tokens1 = Regex.Split(thumbPhoto, "OutputDir");
                                        string thumbPathPhoto = "..\\..\\OutputDir" + tokens1[1];
                                        ListOfThumbPath.Add(new Image(image, originPathPhoto, thumbPhoto, thumbPathPhoto));
                                    }

                                }
                            }
                        }
                    }
                   
                }

            }

        }

        /// <summary>
        /// Adds the image.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="information">The information.</param>
        public void AddImage(object sender, InformConfig information)
        {
            if(information.type == MassageType.Log)
            {
                if (information.message[0].Trim().StartsWith("added"))
                {
                    string[] tmp = information.message[0].Split(' ');
                    string[] pathParts = tmp[1].Split('\\');
                    string outPath = pathParts[0];
                    int i = 1;
                    while(outPath.CompareTo(this.config.OutputDir) != 0)
                    {
                        outPath = outPath + "\\" + pathParts[i];
                        i++;
                    }
                    string lastParameter = "..\\..\\" + pathParts[i-1] + "\\" + "Thumbnails";
                    string relativ = "..\\..\\" + pathParts[i-1];
                    outPath = outPath + "\\" + "Thumbnails";
                    for (; i < pathParts.Length; i++)
                    {
                        outPath = outPath + "\\" + pathParts[i];
                        relativ = relativ + "\\" + pathParts[i]; 
                        lastParameter = lastParameter + "\\" + pathParts[i];
                    }
                    ListOfThumbPath.Add(new Image(tmp[1], relativ, outPath, lastParameter));
                }
            }
        }
    }
}