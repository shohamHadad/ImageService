﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    /// <summary>
    /// Student
    /// </summary>
    public class Student
    {

        /// <summary>
        /// Gets or sets the student identifier.
        /// </summary>
        /// <value>
        /// The student identifier.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "StudentId")]
        public string StudentId { get; set; }

        /// <summary>
        /// Gets or sets the name of the student.
        /// </summary>
        /// <value>
        /// The name of the student.
        /// </value>
        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "StudentName")]
        public string StudentName { get; set; }

        /// <summary>
        /// Gets the students.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns></returns>
        public static List<Student> GetStudents (string path)
        {
            List<Student> studentList = new List<Student>();
            // Create a new stream to read from a file
            StreamReader sr = new StreamReader(HttpContext.Current.Server.MapPath(path));


            string studentDet = sr.ReadToEnd();
            string[] lines = studentDet.Split('\n');
            string[] m_students = lines[0].Split(',');
            string[] m_ids = lines[1].Split(',');

            for(int i = 0; i < m_students.Length; i++)
            {
                studentList.Add(new Student()
                {
                    StudentName = m_students[i],
                    StudentId = m_ids[i]
                });
            }
            return studentList;
        }
        
    }
}
