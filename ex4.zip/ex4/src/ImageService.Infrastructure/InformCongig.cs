﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Infrastructure
{

    /// <summary>
    /// the class InformConfig
    /// </summary>
    public class InformConfig : EventArgs
    {
        /// <summary>
        /// The function MassageType return to type of the massage
        /// </summary>
        /// <return> MassageType </return>
        public MassageType type { get; set; }

        /// <summary>
        /// The function massage do get and set to the massage
        /// </summary>
        /// <return> string </return>
        public string[] message { get; set; }


    }
}
