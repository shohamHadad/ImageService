﻿
using ImageService.Logging.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Logging
{

    /// <summary>
    /// The class LoggingService
    /// </summary>
    public class LoggingService : ILoggingService
    {
        public event EventHandler<MessageRecievedEventArgs> MessageRecieved;
        
        /// <summary>
        /// The Function receive a message and invoke to loger
        /// </summary>
        /// <param name= message> The function gets a massage to the loger </param>
        /// <param name= type> The function gets a type message </param>
        /// <return> return void </return>
        public void Log(string message, MessageTypeEnum type)
        {
            MessageRecieved?.Invoke(this, new MessageRecievedEventArgs(message, type));
        }
    }
}
