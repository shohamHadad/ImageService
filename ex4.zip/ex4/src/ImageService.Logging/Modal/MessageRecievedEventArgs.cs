﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Logging.Modal
{

    /// <summary>
    /// The class MessageRecievedEventArgs
    /// </summary>
    public class MessageRecievedEventArgs : EventArgs
    {


        /// <summary>
        /// constructor
        /// </summary>
        /// <param name= msg> The function gets a meg </param>
        /// <param name= e>The function gets type a message </param>
        public MessageRecievedEventArgs(string msg, MessageTypeEnum e)
        {
            Status = e;
            Message = msg;
        }
        /// <summary>
        ///The funvtion get and set to the Status
        /// </summary>
        /// <return> the function  return the command id </return>
        public MessageTypeEnum Status { get; set; }
        /// <summary>
        ///The funvtion get and set to the message
        /// </summary>
        /// <return> the function  return the command id </return>
        public string Message { get; set; }
    }
}
