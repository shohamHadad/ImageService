﻿using ImageService.Logging.Modal;
using ImageService.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Commands
{
    /// <summary>
    /// The class LogCommand
    /// </summary>
    class LogCommand : ICommand
    {

        /// <summary>
        /// The Function will Execute the command
        /// </summary>
        /// <param name= args> the args to the command </param>
        /// <param name= result> gets false if command executed failed an ture if command executed successfuly </param>
        /// <return> return the result of the command or error message if is failed </return>
        public string Execute(string[] args, out bool result)
        {
            string answer = null;
            foreach(MessageRecievedEventArgs e in LogsReceived.Instance.Event_logs)
            {
                string status = e.Status.ToString();
                string massage = e.Message;
                if(answer == null)
                {
                    answer = massage + "#" + status;
                }
                else
                {
                    answer = answer + "," + massage + "#" + status;
                }
            }
            result = true;
            return answer;
        }
    }
}
