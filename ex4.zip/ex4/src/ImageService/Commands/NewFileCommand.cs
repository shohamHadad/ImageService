﻿using ImageService.Infrastructure;
using ImageService.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Commands
{

    /// <summary>
    /// The class  NewFileCommand created a new file
    /// </summary>
    public class NewFileCommand : ICommand
    {
        private IImageServiceModal m_modal;

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name= modal> the function gets the modal  that we created </param>
        public NewFileCommand(IImageServiceModal modal)
        {
            m_modal = modal;            // Storing the Modal
        }



        /// <summary>
        /// The Function will Execute the command
        /// </summary>
        /// <param name= args> the args to the command </param>
        /// <param name= result> gets false if command executed failed an ture if command executed successfuly </param>
        /// <return> return the result of the command or error message if is failed </return>
        public string Execute(string[] args, out bool result)
        {
            // The String Will Return the New Path if result = true, and will return the error message

            string newPath = m_modal.AddFile(args[0], out result);
            if (result)
            {
                return newPath;
            }
            else
                return "error";
        }
    }
}