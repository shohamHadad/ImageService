﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using ImageService.Server;
using ImageService.Controller;
using ImageService.Modal;
using ImageService.Logging;
using ImageService.Logging.Modal;
using System.Configuration;
using ImageService.Infrastructure;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using ImageService.Client;

namespace ImageService
{

    /// <summary>
    /// the class of the ImageService
    /// </summary>
    public partial class ImageService : ServiceBase
    {

        private ImageServer m_imageServer;          // The Image Server
        private IImageServiceModal modal;
        private IImageController controller;
        private ILoggingService logging;
        private int eventId = 1; 

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool SetServiceStatus(IntPtr handle, ref ServiceStatus serviceStatus);


        /// <summary>
        /// the constructor of the Image Service
        /// </summary>
        /// <param name= args>the function gets the args</param>
        public ImageService(string[] args)
        {
            //
            InitializeComponent();
            string eventSourceName = "MySource";
            string logName = "MyNewLog";
            if (args.Count() > 0)
            {
                eventSourceName = args[0];
            }
            if (args.Count() > 1)
            {
                logName = args[1];
            }

            eventLog1 = new System.Diagnostics.EventLog();
            if (!System.Diagnostics.EventLog.SourceExists(eventSourceName))
            {
                System.Diagnostics.EventLog.CreateEventSource(
                    eventSourceName, logName);
            }
            eventLog1.Source = eventSourceName;
            eventLog1.Log = logName;
            //creat the logs list
            LogsReceived listOfLogs = LogsReceived.Instance;
        }


        /// <summary>
        /// the function that starts to runs when the service starts running
        /// </summary>
        /// <param name= args>the function gets the args</param>
        /// <return> void </return>
        protected override void OnStart(string[] args)
        {
            string[] sendConfig = new string[5];
            this.logging = new LoggingService();
            this.logging.MessageRecieved += MassageFromLog;
            //  reading from the .config file
            int result, m_ThumbnailSize = 120;
            string m_Handler = ConfigurationManager.AppSettings["Handler"];
            string[] m_handlers = m_Handler.Split(';');
            string m_OutputDir = ConfigurationManager.AppSettings["OutputDir"];
            sendConfig[0] = m_OutputDir;
            string m_SourceName = ConfigurationManager.AppSettings["SourceName"];
            sendConfig[1] = m_SourceName;
            string m_LogName = ConfigurationManager.AppSettings["LogName"];
            sendConfig[2] = m_LogName;


            int.TryParse(ConfigurationManager.AppSettings["ThumbnailSize"], out result);
            if (result != 0)
            {
                m_ThumbnailSize = int.Parse(ConfigurationManager.AppSettings["ThumbnailSize"]);
            }

            sendConfig[3] = m_ThumbnailSize.ToString();
            Config config = Config.Instance(sendConfig, m_handlers);
            eventLog1.Source = m_SourceName;
            eventLog1.Log = m_LogName;
            //creat image modal,server and controller
            this.modal = new ImageServiceModal(m_OutputDir, m_ThumbnailSize);
            
            this.m_imageServer = new ImageServer(this.logging, this.modal, m_handlers);
            //this.controller = new ImageController(this.modal, this.m_imageServer);
            //this.m_imageServer.m_controller = this.controller;
            //creat tcp server
            TcpServer tcp_server = new TcpServer(8000, this.logging, this.m_imageServer.m_controller);
            AndroidServer appServer = new AndroidServer(this.logging);
            tcp_server.Start();
            //sign to log event
            this.logging.MessageRecieved += tcp_server.SendLog;
            this.logging.MessageRecieved += LogsReceived.Instance.AddEvent;
            eventLog1.WriteEntry("In OnStart");

            // Set up a timer to trigger every minute.  
            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Interval = 60000; // 60 seconds  
            timer.Elapsed += new System.Timers.ElapsedEventHandler(this.OnTimer);
            timer.Start();

            // Update the service state to Start Pending.  
            ServiceStatus serviceStatus = new ServiceStatus();
            serviceStatus.dwCurrentState = ServiceState.SERVICE_START_PENDING;
            serviceStatus.dwWaitHint = 100000;
            SetServiceStatus(this.ServiceHandle, ref serviceStatus);

            // Update the service state to Running.  
            serviceStatus.dwCurrentState = ServiceState.SERVICE_RUNNING;
            SetServiceStatus(this.ServiceHandle, ref serviceStatus);
        }

        /// <summary>
        /// the function that starts to runs when the service stops running
        /// </summary>
        /// <return> void </return>
        protected override void OnStop()
        {

            this.m_imageServer.sendRemoveCommand();

            eventLog1.WriteEntry("In onStop.");

            // Update the service state to Start Pending.  
            ServiceStatus serviceStatus = new ServiceStatus();
            serviceStatus.dwCurrentState = ServiceState.SERVICE_START_PENDING;
            serviceStatus.dwWaitHint = 100000;
            SetServiceStatus(this.ServiceHandle, ref serviceStatus);

            // Update the service state to Running.  
            serviceStatus.dwCurrentState = ServiceState.SERVICE_RUNNING;
            SetServiceStatus(this.ServiceHandle, ref serviceStatus);
        }


        /// <summary>
        /// the function that runs when monitoring the directories
        /// </summary>
        /// <return> void </return>
        public void OnTimer(object sender, System.Timers.ElapsedEventArgs args)
        {
            // TODO: Insert monitoring activities here.  
            eventLog1.WriteEntry("Monitoring the System", EventLogEntryType.Information, eventId++);
        }


        /// <summary>
        /// the function write messages to the logger
        /// </summary>
        /// <param name= sender> the function gets sender object </param>
        /// <param name= e> the event that received the command </param>
        /// <return> void </return>
        private void MassageFromLog(object sender, MessageRecievedEventArgs e)
        {
            eventLog1.WriteEntry(e.Message);
        }

    }

    public enum ServiceState
    {
        SERVICE_STOPPED = 0x00000001,
        SERVICE_START_PENDING = 0x00000002,
        SERVICE_STOP_PENDING = 0x00000003,
        SERVICE_RUNNING = 0x00000004,
        SERVICE_CONTINUE_PENDING = 0x00000005,
        SERVICE_PAUSE_PENDING = 0x00000006,
        SERVICE_PAUSED = 0x00000007,
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct ServiceStatus
    {
        public int dwServiceType;
        public ServiceState dwCurrentState;
        public int dwControlsAccepted;
        public int dwWin32ExitCode;
        public int dwServiceSpecificExitCode;
        public int dwCheckPoint;
        public int dwWaitHint;
    };

}