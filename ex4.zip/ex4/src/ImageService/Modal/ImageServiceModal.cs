﻿using ImageService.Infrastructure;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace ImageService.Modal
{
    public class ImageServiceModal : IImageServiceModal
    {
        #region Members
        private string m_OutputFolder;            // The Output Folder
        private int m_thumbnailSize;              // The Size Of The Thumbnail Size

        #endregion

        /// <summary>
        /// constructor
        /// </summary>         
        /// <param name= Output> the path of the image that we want to copy to the folder </param>
        /// <param name= thumb> the thumb of the thumbnail that we create </param>
        public ImageServiceModal(string Output, int thumb)
        {
            this.m_OutputFolder = Output;
            this.m_thumbnailSize = thumb;
        }


        /// <summary>
        /// The Function Addes A file to the system
        /// </summary>
        /// <param name="path">The Path of the Image from the file</param>
        /// <param name= result> gets false if command executed  failed an ture if command executed successfuly </param>
        /// <returns>Indication if the Addition Was Successful</returns>
        public string AddFile(string path, out bool result)
        {
            
            // find the image date
            DateTime time = DateTime.Now;
            TimeSpan local = time - time.ToUniversalTime();
            DateTime forFile = File.GetLastWriteTimeUtc(path) + local;
            DateTime creation = File.GetCreationTime(path);
            string year = "0", month="0", updateYearPath, updateMonthPath, thumbupdateYearPath, thumbupdateMonthPath, s, samePath;
            string[] update;
            try {
                year = forFile.Year.ToString();
                month = forFile.Month.ToString();
                // update a new path to Output Folder
                updateYearPath = this.m_OutputFolder + "\\" + year.ToString();
                updateMonthPath = this.m_OutputFolder + "\\" + year.ToString() + "\\" + month;
                // OutputFolder to thumbnail folder
                thumbupdateYearPath = this.m_OutputFolder + "\\Thumbnails" + "\\" + year;
                thumbupdateMonthPath = this.m_OutputFolder + "\\Thumbnails" + "\\" + year + "\\" + month.ToString();
                s = path.Substring(path.LastIndexOf("\\"));
                update = s.Split('.');
                            }
            catch (Exception e) {
                // update a new path to Output Folder
                updateYearPath = this.m_OutputFolder + "\\0";
                updateMonthPath = updateYearPath + "\\0";
                // OutputFolder to thumbnail folder
                thumbupdateYearPath = this.m_OutputFolder + "\\Thumbnails" + "\\0";
                thumbupdateMonthPath = thumbupdateYearPath + "\\0";
                s = path.Substring(path.LastIndexOf("\\"));
                update = s.Split('.');
            }
            int counter = -1;
            


            DirectoryInfo di;

            try
            {
                //creat new folders if dont exist
                // Try to create the directory.
                di = Directory.CreateDirectory(this.m_OutputFolder);
                di.Attributes = FileAttributes.Directory | FileAttributes.Hidden;
                Directory.CreateDirectory(updateMonthPath);
                Directory.CreateDirectory(thumbupdateMonthPath);
                // move image to this folder


                Image image = Image.FromFile(path);
                Image thumbnailSize = image.GetThumbnailImage(m_thumbnailSize, m_thumbnailSize, () => false, IntPtr.Zero);
                updateMonthPath = updateMonthPath + path.Substring(path.LastIndexOf("\\"));
                if (File.Exists(updateMonthPath))
                {
                    samePath = updateYearPath + "\\" + month.ToString() + "\\" + update[0] + "-1." + update[1];
                    while (File.Exists(samePath))
                    {
                        counter--;
                        samePath = updateYearPath + "\\" + month.ToString() + "\\" + update[0] + counter.ToString() + "." + update[1];
                    }
                    File.Move(updateMonthPath, samePath);
                }
                image.Save(updateMonthPath);
                // saving thumbnail image
                thumbupdateMonthPath = thumbupdateMonthPath + update[0] + '.' + "thumbnailSize";
                if (File.Exists(Path.ChangeExtension(thumbupdateMonthPath, "jpg")))
                {
                    counter = -1;
                    samePath = thumbupdateYearPath + "\\" + month.ToString() + "\\" + update[0] + "-1." + update[1];
                    while (File.Exists(samePath))
                    {
                        counter--;
                        samePath = thumbupdateYearPath + "\\" + month.ToString() + "\\" + update[0] + counter.ToString() + "." + update[1];
                    }
                    // File.Move(thumbupdateMonthPath, samePath);
                    thumbnailSize.Save(Path.ChangeExtension(samePath, "jpg"));
                }
                thumbnailSize.Save(Path.ChangeExtension(thumbupdateMonthPath, "jpg"));
                image.Dispose();
                thumbnailSize.Dispose();
            }
            catch (Exception e)
            {
                result = false;
                return e.Message;
            }

            result = true;
            return updateMonthPath;
        }

    }
}