﻿using ImageService.Logging;
using ImageService.Logging.Modal;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

/// <summary>
/// AndroidServer
/// </summary>
namespace ImageService.Server
{
    class AndroidServer
    {
        private List<string> handlers;
        private Mutex mtx;
        private ILoggingService m_logging;


        /// <summary>
        /// Initializes a new instance of the <see cref="AndroidServer"/> class.
        /// </summary>
        /// <param name="m_logging">The m logging.</param>
        public AndroidServer(ILoggingService m_logging)
        {
            this.m_logging = m_logging;
            this.handlers = Config.Instance(null, null).handlers;
            this.mtx = new Mutex();
            this.SendRecieve();
        }

        // recieve a massage of byte[] and convert it to image , move them to handler folder and sends message to the 
        //android app
        /// <summary>
        /// Sends the recieve.
        /// </summary>
        private void SendRecieve()
        {
            //open connection
            IPEndPoint ep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8000);
            TcpListener listener = new TcpListener(ep);
            listener.Start();
            Console.WriteLine("Waiting for connections...");
            Task task = new Task(() =>
            {
                //accepting clients
                while (true)
                {
                    try
                    {
                        TcpClient client = listener.AcceptTcpClient();
                        while (true)
                        {
                            NetworkStream stream = client.GetStream();
                            BinaryReader reader = new BinaryReader(stream);
                            // Check to see if this NetworkStream is readable.
                            byte[] myReadBufferImage;
                            byte[] myReadBufferName;
                            byte[] bytes;
                            int picSize;
                            byte[] sendMes = new byte[1024];
                            int numberOfBytesRead = 0;
                            Mutex mtx = new Mutex();
                            string ImageName;
                            //image size
                            bytes = reader.ReadBytes(4);

                            if (BitConverter.IsLittleEndian)
                                Array.Reverse(bytes);

                            int PicSize = BitConverter.ToInt32(bytes, 0);
                            //picSize = int.Parse(PicSize);

                            //image
                            //numberOfBytesRead = stream.Read(myReadBufferImage, 0, picSize);
                            myReadBufferImage = reader.ReadBytes(PicSize);
                            
                            sendMes = Encoding.ASCII.GetBytes("got Image");
                            mtx.WaitOne();
                            stream.Write(sendMes, 0, sendMes.Length);
                            stream.Flush();
                            mtx.ReleaseMutex();

                            // read size name of image
                            bytes = reader.ReadBytes(4);
                            if (BitConverter.IsLittleEndian)
                                Array.Reverse(bytes);
                            int name_size = BitConverter.ToInt32(bytes, 0);

                            // Array.Clear(myReadBufferName,0, myReadBufferName.Length);
                            //string ImgSize = Encoding.ASCII.GetString(bytes, 0, name_size);
                            //int imgSize = int.Parse(ImgSize);

                            // read image name
                            myReadBufferName = reader.ReadBytes(name_size);
                            ImageName = Encoding.ASCII.GetString(myReadBufferName, 0, name_size);
                          

                            sendMes = Encoding.ASCII.GetBytes("got ImageName");
                            mtx.WaitOne();
                            stream.Write(sendMes, 0, sendMes.Length);
                            stream.Flush();
                            mtx.ReleaseMutex();

                            MoveToHandlerD(myReadBufferImage, ImageName);
                        }

                    }
                    catch (Exception e)
                    {
                        this.m_logging.Log(e.Message, MessageTypeEnum.FAIL);
                    }
                }
            });
            task.Start();
        }

        /// <summary>
        /// Moves to handler d.
        /// </summary>
        /// <param name="myReadBufferImage">My read buffer image.</param>
        /// <param name="ImageName">Name of the image.</param>
        public void MoveToHandlerD(byte[] myReadBufferImage, string ImageName)
        {
            if (this.handlers.Count > 0)
            {

                File.WriteAllBytes(this.handlers.ToArray()[0] + "\\" + ImageName, myReadBufferImage);
            }

        }
    }
}