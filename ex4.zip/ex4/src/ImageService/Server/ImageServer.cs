﻿using ImageService.Controller;
using ImageService.Controller.Handlers;
using ImageService.Infrastructure.Enums;
using ImageService.Logging;
using ImageService.Logging.Modal;
using ImageService.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Server
{

    /// <summary>
    /// the class ImageServer
    /// </summary>
    public class ImageServer
    {
        #region Members
        private ILoggingService m_logging;
        private string[] m_paths;
        private IImageServiceModal m_model;
        public IImageController m_controller { get; set; }
        #endregion

        #region Properties

        public event EventHandler<CommandRecievedEventArgs> CommandRecieved;    // The event that notifies about a new Command being recieved.
        #endregion


        /// <summary>
        /// constuctor
        /// </summary>
        /// <param name= logger>The function gets logger</param>
        /// <param name= controller>The function gets controller</param>
        /// <param name= paths>The function gats the paths to all the directories that we want to handler </param>
        public ImageServer(ILoggingService logger, IImageServiceModal model, string[] paths)
        {
            this.m_logging = logger;
            this.m_model = model;
            this.m_controller = new ImageController(m_model,this);
            this.m_paths = paths;
            //server creats handlers for each path we got
            foreach (string p in m_paths)
            {
                createHandler(p);
            }

        }
        /// <summary>
        /// The function creates a new handler for a given directory
        /// </summary>
        /// <param name= path>The function gats the path to the directory that we want to handler </param>
        /// <return> void </return>
        public void createHandler(string path)
        {
            IDirectoryHandler dirHandler = new DirectoyHandler(m_controller, m_logging);
            dirHandler.DirectoryClose += CloseHandlerListen;
            this.CommandRecieved += dirHandler.OnCommandRecieved;
            dirHandler.StartHandleDirectory(path);
        }



        /// <summary>
        /// The function sendCommand
        /// </summary>
        /// <param name= p>The function gats the path to the directory that we want to handler </param>
        /// <return> void </return>
        public void sendCommand(string path)
        {
            string msg;       
            msg = "closed" + path;
            this.CommandRecieved?.Invoke(this, new CommandRecievedEventArgs(-1, null, path));
            this.m_logging.Log(msg, Logging.Modal.MessageTypeEnum.INFO);
            Config tmp = Config.Instance(null, null);
            int x = tmp.handlers.IndexOf(path);
            tmp.handlers.RemoveAt(x);
            this.m_paths = this.m_paths.Where(val => val != path).ToArray();

        }

        /// <summary>
        /// The function sendRemoveCommand
        /// </summary>
        /// <return> void </return>
        public void sendRemoveCommand()
        {
            string msg;
            foreach (string p in m_paths)
             {
                msg = "closed" + p;
                this.CommandRecieved?.Invoke(this, new CommandRecievedEventArgs(-1, null, p));
                this.m_logging.Log(msg, Logging.Modal.MessageTypeEnum.INFO);
                this.m_paths = this.m_paths.Where(val => val != p).ToArray();
            }
        }

        /// <summary>
        /// The function  CloseHandlerListen -The function stop to handler 
        /// </summary>
        /// <param name= sender> the function gets sender object </param>
        /// <param name= e> the event that received the command </param>
        /// <return> void </return>
        private void CloseHandlerListen(object sender, DirectoryCloseEventArgs e)
        {
            IDirectoryHandler CloseHandler = (IDirectoryHandler)sender;
            this.CommandRecieved -= CloseHandler.OnCommandRecieved;
        }

    }
}