﻿using ImageService.Client;
using ImageService.Controller;
using ImageService.Logging;
using ImageService.Logging.Modal;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ImageService.Server
{
    /// <summary>
    /// the class TcpServer
    /// </summary>
    class TcpServer
    {
        private int m_port;
        private TcpListener m_listener;
        private ILoggingService m_logging;
        private IImageController m_controller;
        private IClientHandler ch;
        private List<Tcp_Client> clients;

        /// <summary>
        /// constuctor
        /// </summary>
        /// <param name= port>The function gets port</param>
        /// <param name= logging>The function gets logging (log service)</param>
        /// <param name= con>The function gats Controller</param>
        public TcpServer(int port, ILoggingService logging, IImageController con)
        {
            this.m_port = port;
            this.m_logging = logging;
            this.m_controller = con;
            this.clients = new List<Tcp_Client>();
        }

        /// <summary>
        /// The function start the Tcp server
        /// </summary>
        /// <return> void </return>
        public void Start()
        {

            IPEndPoint ep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8008);
            TcpListener listener = new TcpListener(ep);
            this.ch = new ClientHandler();
            listener.Start();
            Console.WriteLine("Waiting for connections...");
            Task task = new Task(() =>
            {
                //accepting clients
                while (true)
                {
                    try
                    {
                        TcpClient client = listener.AcceptTcpClient();
                        Tcp_Client tcp_client = new Tcp_Client(client);
                        this.clients.Add(tcp_client);
                        Console.WriteLine("Got new connection");
                        ch.HandleClient(tcp_client, m_controller);
                    }
                    catch (SocketException)
                    {
                        break;
                    }

                }
            });
            task.Start();
        }


        /// <summary>
        /// The function  send the log message 
        /// </summary>
        /// <param name= sender> the function gets sender object </param>
        /// <param name= e> the event that received the command </param>
        /// <return> void </return>
        public void SendLog(object sender, MessageRecievedEventArgs e)
        {
            foreach (Tcp_Client tcp_client in this.clients)
            {
                if (tcp_client.Tc_client.Connected)
                {
                    this.ch.SendMessageToGui(tcp_client, e);
                }
            }
        }

        /// <summary>
        /// The function stop the Tcp server
        /// </summary>
        /// <return> void </return>
        public void Stop()
        {
            m_listener.Stop();
        }
    }
}