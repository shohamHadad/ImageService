package com.example.gs.imageandroid;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import static android.content.ContentValues.TAG;

/**
 *class ImageServiceService
 */
public class ImageServiceService extends Service {

    private BroadcastReceiver yourReceiver;
    private Socket socket;
    private DataOutputStream output;
    private InputStream input;

    /**
     *
     * @param intent
     * @return null
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent){
        return null;
    }

    /**
     * open socket when class is created.
     */
    @Override
    public void onCreate(){
        super.onCreate();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    InetAddress serverAddr = InetAddress.getByName("10.0.2.2");
                    socket = new Socket(serverAddr, 8000);
                    try {
                        output = new DataOutputStream(socket.getOutputStream());
                        input = socket.getInputStream();
                    } catch (Exception e) {
                        Log.e("TCP", "S: Error:", e);
                    }
                } catch (Exception e) {
                    Log.e("TCP", "S: Error:", e);
                }
            }
        });
        thread.start();
    }

    /**
     * starts the service
     * @param intent
     * @param flag
     * @param startId
     * @return START_STICKY int
     */
    public int onStartCommand(Intent intent, int flag, int startId){
        Toast.makeText(this,"Service starting...", Toast.LENGTH_SHORT).show();
        // Getting the Camera Folder
        getWIFI();
        return START_STICKY;
    }

    /**
     * called when push stop button.
     */
    public void onDestroy() {
        super.onDestroy();

        Toast.makeText(this,"Service ending...", Toast.LENGTH_SHORT).show();


        //closes the connection
        try {
            this.socket.close();
        } catch (Exception e) {
            Log.e("TCP", "Error:", e);
        }
    }

    /**
     * check for wifi conection and send the pictures in the DCIM directory
     * to a server .
     */
    public void getWIFI() {
        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("android.net.wifi.supplicant.CONNECTION_CHANGE");
        theFilter.addAction("android.net.wifi.STATE_CHANGE");

/*

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
        builder.setContentTitle("Picture Transfer").setContentText("Transfer in progress")
                .setPriority(NotificationCompat.PRIORITY_LOW);
        builder.setContentText("Half way through").setProgress(100, 50, false);
        notificationManager.notify(1, builder.build());
        // At the End
        builder.setContentText("Download complete").setProgress(0, 0, false);
        notificationManager.notify(1, builder.build());

*/

        this.yourReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
                NetworkInfo networkInfo = intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
                Log.d(TAG, "onReceive: EVENT RECEIVED");
                if (networkInfo != null) {
                    if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                     //get the different network states
                        if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {
                             startTransfer();
                        }
                    }
                }
            }
        };
        this.registerReceiver(this.yourReceiver, theFilter);
    }

    /**
     * send the pictures - using tcp connection.
     */
    public void startTransfer(){
        final File dcim = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
        if (dcim == null) {
            return ;
        }
        final List<File> pics = getListFiles2(dcim);
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                int count =0;
                if (pics != null) {
                    for (File pic : pics) {
                        try {
                            String s;
                            FileInputStream fis = new FileInputStream(pic);
                            Bitmap bm = BitmapFactory.decodeStream(fis);
                            byte[] imgbyte = getBytesFromBitmap(bm);
                            byte[] b = new byte[1024];
                            try {
                                //image size
                                output.writeInt(imgbyte.length);
                                output.flush();

                                //image sending
                                output.write(imgbyte);
                                output.flush();
                                input.read(b);
                                s = new String(b);
                                while (!s.contains("got Image")) {
                                    input.read(b);
                                    s = new String(b);
                                }
                                Log.d(TAG, s);

                                //image name size
                                String toSend = pic.getName();
                                byte[] image_name = toSend.getBytes();
                                output.writeInt(image_name.length);
                                output.flush();
                                Thread.sleep(100);

                                //sending image name
                                output.write(image_name, 0, image_name.length);
                                output.flush();
                                Thread.sleep(500);
                                input.read(b);
                                s = new String(b);
                                while (!s.contains("got ImageName")) {
                                    input.read(b);
                                    s = new String(b);
                                }
                                Log.d(TAG, s);
                            } catch (Exception e) {
                                Log.d(TAG, e.getMessage());
                            }
                        }catch(Exception ex){

                        }
                    }
                }
            }
        });
        thread.start();
    }

    //return byte array from a picture
    private byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 70, stream);
        return stream.toByteArray();
    }
// read all subdirectories files
    private List<File> getListFiles2(File parentDir) {
        List<File> inFiles = new ArrayList<>();
        Queue<File> files = new LinkedList<>();
        File[] tempF = parentDir.listFiles();
        if(tempF == null){
            return null;
        }
        files.addAll(Arrays.asList(tempF));
        while (!files.isEmpty()) {
            File file = files.remove();
            if (file.isDirectory()) {
                files.addAll(Arrays.asList(file.listFiles()));
            } else {
                inFiles.add(file);
            }
        }
        return inFiles;
    }

}
